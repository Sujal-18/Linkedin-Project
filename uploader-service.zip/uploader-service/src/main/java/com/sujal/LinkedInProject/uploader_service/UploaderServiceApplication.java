package com.sujal.LinkedInProject.uploader_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploaderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploaderServiceApplication.class, args);
	}

}
